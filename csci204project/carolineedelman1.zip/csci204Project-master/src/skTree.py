"""
Will be used to make a decision tree using sklearn
More details will be added to this later
"""

import math
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.tree import export_graphviz


class SKTree:
    
    def __init__(self):
        """
        More information will be given about this later
        """
        pass


    def train(self, xData, yData, maxDepth):
        pass

    
    def eval(self, xData):
        pass


def testSKTree():
    """
    Used to test my SKTree
    """
    pass

if __name__ == "__main__":
    testSKTree()
