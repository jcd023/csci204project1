"""
Will be used later to do PCA Analysis
"""


import math
import numpy as np
from sklearn import decomposition


class SKPCA:
    """
    More help will be added for this later
    """
    
    def __init_(self):
        """
        init all variables used
        """
        pass

    
    def train(self, xData, yData, numComponents):
        pass


    def eval(self, XData):
        pass


def testSKPCA():
    """
    Used to test my SKPCA
    """
    pass


if __name__ == "__main__":
    testSKPCA()
