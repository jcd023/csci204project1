"""
This file contains a class that is used to find the social network 
of a set of data.
A lot more to come.
"""


class SNetwork:

    def __init__(self):
        """
        TO COME
        """
        pass

