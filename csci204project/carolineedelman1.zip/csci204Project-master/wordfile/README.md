Will contain a file with words to strip from the document
