Where you will place your completed manual
