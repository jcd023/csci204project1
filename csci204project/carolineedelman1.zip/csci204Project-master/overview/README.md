information on what to be added to project
